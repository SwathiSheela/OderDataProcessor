﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderDataProcessor.Models
{
    public class DetailRecord
    {
        public string PurchaseOrderNumber { get; set; }
        public int LineNumber { get; set; }
        public string ItemDescription { get; set; }
        public int OrderQuantity { get; set; }
        public int OrderQty { get; set; }
    }
}