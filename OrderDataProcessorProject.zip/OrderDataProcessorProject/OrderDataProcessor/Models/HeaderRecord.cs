﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderDataProcessor.Models
{
    public class HeaderRecord
    {
        public string PurchaseOrderNumber { get; set; }
        public string Supplier { get; set; }
        public string Origin { get; set; }
        public string Destination { get; set; }
        public DateTime CargoReadyDate { get; set; }
    }
}